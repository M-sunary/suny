package com.example.suny;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SunyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SunyApplication.class, args);
	}
}
